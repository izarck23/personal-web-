import { useState } from 'react';
import { Link } from '@tanstack/react-router';

import { ArrowUpRight, Code2, Menu, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { SocialLinks } from './social';

export const navigation = ['Home', 'About', 'Services', 'Portfolio', 'Blog', 'Contact'];
const sectionHref = (name: string, onHome: boolean) => {
  const id = name.toLowerCase();
  
  
  return onHome ? `#${id}` : `/#${id}`;
};

export function SiteHeader({ activeSection, onHome = false }: { activeSection?: string; onHome?: boolean }) {
  const [menuOpen, setMenuOpen] = useState(false);
  return <header className="site-header"><nav className="nav-bar" aria-label="Main navigation">
    <a className="brand" href={onHome ? '#home' : '/'} onClick={() => setMenuOpen(false)}><span className="brand-icon"><Code2 size={17} aria-hidden="true" /></span>CoderTech<span className="orange">.</span></a>
    <div className={`nav-links ${menuOpen ? 'open' : ''}`} id="main-navigation">{navigation.map((name) => { const active = activeSection === name.toLowerCase(); return <a key={name} href={sectionHref(name, onHome)} onClick={() => setMenuOpen(false)} className={`${active ? 'active' : ''} ${name === 'Contact' ? 'nav-contact' : ''}`} aria-current={active ? (onHome ? 'location' : 'page') : undefined}>{name}{name === 'Contact' && <ArrowUpRight size={14} aria-hidden="true" />}</a>; })}<Link to="/shop" onClick={() => setMenuOpen(false)}>Shop</Link></div>
    <Button variant="portfolioIcon" size="icon" className="menu-toggle" aria-label={menuOpen ? 'Close navigation' : 'Open navigation'} aria-expanded={menuOpen} aria-controls="main-navigation" onClick={() => setMenuOpen(!menuOpen)}>{menuOpen ? <X /> : <Menu />}</Button>
  </nav></header>;
}

export function SiteFooter({ onHire, onHome = false }: { onHire?: () => void; onHome?: boolean }) {
  const hire = onHire ? <Button variant="portfolio" onClick={onHire}>Hire Me<ArrowUpRight /></Button> : <Button variant="portfolio" asChild><a href="/#contact">Hire Me<ArrowUpRight /></a></Button>;
  return <footer className="site-footer"><div className="container"><div className="footer-top"><h2>Let’s Connect</h2>{hire}</div><div className="footer-columns">
    <div className="footer-intro"><a className="brand" href={onHome ? '#home' : '/'}><span className="brand-icon"><Code2 size={16} aria-hidden="true" /></span>CoderTech<span className="orange">.</span></a><p>Software, apps and websites.<br />Isaac · Software & App Developer · Kenya.</p><SocialLinks /></div>
    <div className="footer-column"><h3>Navigation</h3>{navigation.map((name) => <a key={name} href={sectionHref(name, onHome)}>{name}</a>)}</div>
    <div className="footer-column"><h3>Let’s work together</h3><p>Have something in mind?</p><p>I’d love to hear about it.</p>{onHire ? <Button variant="portfolioOutline" onClick={onHire}>Start a conversation<ArrowUpRight /></Button> : <Button variant="portfolioOutline" asChild><a href="/#contact">Start a conversation<ArrowUpRight /></a></Button>}</div>
  </div><div className="footer-bottom"><span>© 2026 CoderTech. All rights reserved.</span><span>Isaac · Kenya</span></div></div></footer>;
}
