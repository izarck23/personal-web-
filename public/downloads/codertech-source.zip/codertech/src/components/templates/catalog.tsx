import { useState } from 'react';
import { Link } from '@tanstack/react-router';
import { ArrowUpRight, Download, ShoppingCart, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { InquiryModal } from '@/components/portfolio/modal';
import { templates, templateURL, templateZip, addCartItem, cartTotal, type Template } from '@/content/templates';
import { useTemplateCart } from './cart';

export function TemplatePreview({ template }: { template: Template }) {
  const [file, setFile] = useState(template.pages[0]?.file ?? 'index.html');
  const [mobile, setMobile] = useState(false);
  return <div className="template-preview"><div className="preview-toolbar"><div role="group" aria-label="Screen preview">{template.pages.map((page) => <Button key={page.file} variant={file === page.file ? 'portfolio' : 'portfolioOutline'} aria-pressed={file === page.file} onClick={() => setFile(page.file)}>{page.label}</Button>)}</div><div role="group" aria-label="Preview size"><Button variant="portfolioOutline" aria-pressed={!mobile} onClick={() => setMobile(false)}>Desktop</Button><Button variant="portfolioOutline" aria-pressed={mobile} onClick={() => setMobile(true)}>Mobile</Button></div></div><div className={`preview-stage ${mobile ? 'preview-mobile' : ''}`}><iframe key={file} title={`${template.title} — ${file} preview`} src={templateURL(template.slug, file)} sandbox="allow-scripts allow-forms" loading="lazy" /></div><Button variant="portfolioOutline" asChild><a href={templateURL(template.slug, file)} target="_blank" rel="noopener noreferrer">Open full preview<ArrowUpRight /></a></Button></div>;
}

export function TemplateCatalog({ selected }: { selected?: Template }) {
  const { cart, setCart } = useTemplateCart();
  const [notice, setNotice] = useState('');
  const [request, setRequest] = useState<string | null>(null);
  const [showCart, setShowCart] = useState(false);
  const visible = selected ? [selected] : templates;
  function add(template: Template) { setCart((current) => addCartItem(current, template.slug)); setNotice(`${template.title} added to cart. Pricing is awaiting confirmation.`); }
  const total = cartTotal(cart);
  return <><div className="catalog-top"><div><div className="eyebrow">Standalone HTML & CSS</div><h1 className="section-heading">{selected ? selected.title : 'Template shop'}</h1><p>{selected ? selected.description : 'Landing pages, startup websites and account screens by Isaac.'}</p></div><Button variant="portfolioOutline" onClick={() => setShowCart(!showCart)} aria-expanded={showCart} aria-controls="template-cart"><ShoppingCart />Cart ({cart.length})</Button></div>
    <p className="catalog-notice">Prices to be confirmed. Payment checkout is not connected; editable ZIPs are currently available directly.</p>
    <div role="status" className="form-status">{notice}</div>
    {showCart && <section id="template-cart" className="template-cart" aria-label="Template cart"><h2>Your cart</h2>{cart.length ? <>{templates.filter((item) => cart.includes(item.slug)).map((item) => <div className="cart-row" key={item.slug}><span>{item.title}<small>Price to be confirmed</small></span><Button variant="portfolioIcon" size="icon" aria-label={`Remove ${item.title} from cart`} onClick={() => { setCart(cart.filter((slug) => slug !== item.slug)); setNotice(`${item.title} removed from cart.`); }}><Trash2 /></Button></div>)}<p>Total: {total === null ? 'To be confirmed' : total === 0 ? 'No priced items' : `KSh ${total}`}</p><Button variant="portfolio" onClick={() => setRequest(cart.map((slug) => templates.find((item) => item.slug === slug)?.title).join(', '))}>Request these templates<ArrowUpRight /></Button><Button variant="portfolioOutline" disabled>Checkout unavailable</Button></> : <p>Your cart is empty.</p>}</section>}
    <div className={selected ? 'template-details' : 'template-grid'}>{visible.map((item) => <article className="template-item" key={item.slug}>{selected ? <TemplatePreview template={item} /> : <><div className="catalog-thumb"><iframe title={`${item.title} preview thumbnail`} src={templateURL(item.slug)} sandbox="" loading="lazy" tabIndex={-1} /><Link className="catalog-thumb-link" to="/templates/$slug" params={{ slug: item.slug }} aria-label={`Preview ${item.title}`} /></div><div className="eyebrow">{item.category}</div><h2>{item.title}</h2><p>{item.description}</p></>}
      <ul>{item.includes.map((feature) => <li key={feature}>{feature}</li>)}</ul><p className="template-price">Price to be confirmed</p><div className="template-actions">{!selected && <Button variant="portfolio" asChild><Link to="/templates/$slug" params={{ slug: item.slug }}>Preview & details<ArrowUpRight /></Link></Button>}<Button variant="portfolioOutline" onClick={() => add(item)}><ShoppingCart />Add to cart</Button>{selected && <Button variant="portfolio" asChild><a href={templateZip(item.slug)} download><Download />Editable code (ZIP)</a></Button>}<Button variant="portfolioOutline" onClick={() => setRequest(item.title)}>Request a project<ArrowUpRight /></Button></div>
      {selected && <div className="template-guide"><h2>Add it to your project</h2><ol><li>Download and extract the ZIP into its own folder, outside the CoderTech website.</li><li>Open index.html in VS Code or Acode. Edit page text in the HTML files and colours in :root in styles.css.</li><li>Keep styles.css beside the HTML files. Copy the sections you need into your project and adapt the styles to your brand.</li><li>For a local preview in Termux: install Python, open the extracted folder and run <code>python -m http.server 8000</code>. Visit <code>http://localhost:8000</code>. You can also open index.html directly.</li><li>Connect forms to your own trusted service before publishing. Authentication screens do not sign anyone in or send password emails.</li></ol><p>Included: HTML pages, styles.css, README.txt and LICENSE.txt. No framework, installation or build step required. The licence permits personal and client use, not redistribution or resale of the template files.</p><Button variant="portfolioOutline" asChild><a href={templateURL(item.slug)} target="_blank" rel="noopener noreferrer">View editable HTML<ArrowUpRight /></a></Button></div>}
    </article>)}</div>{selected && <Button variant="portfolioOutline" asChild><Link to="/shop">All templates<ArrowUpRight /></Link></Button>}
    <InquiryModal open={request !== null} projectName={request ?? undefined} onClose={() => setRequest(null)} />
  </>;
}
