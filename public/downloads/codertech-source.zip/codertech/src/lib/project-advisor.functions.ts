import { createServerFn } from '@tanstack/react-start';
import { z } from 'zod';

const SERVICES = ['App Development', 'Website Development', 'Landing Pages'] as const;

const resultSchema = z.object({
  services: z.array(z.object({ name: z.enum(SERVICES), reason: z.string() })),
  inquiry: z.string(),
});
export type AdvisorResult = z.infer<typeof resultSchema> | { error: string };

export const recommendServices = createServerFn({ method: 'POST' })
  .inputValidator((input: { needs: string }) => {
    const needs = String(input?.needs ?? '').trim();
    if (needs.length < 10 || needs.length > 2000) throw new Error('Please describe your project in 10–2000 characters.');
    return { needs };
  })
  .handler(async ({ data }): Promise<AdvisorResult> => {
    const apiKey = process.env['LOVABLE_API_KEY'];
    if (!apiKey) return { error: 'The assistant is not configured yet.' };
    const { createOpenAI } = await import('@ai-sdk/openai');
    const { streamText, Output } = await import('ai');
    const provider = createOpenAI({
      baseURL: 'https://ai.gateway.lovable.dev/v1',
      apiKey,
      headers: { 'Lovable-API-Key': apiKey, 'X-Lovable-AIG-SDK': 'vercel-ai-sdk' },
    });
    try {
      const result = streamText({
        model: provider.responses('openai/gpt-6-astra'),
        system: `You help prospective clients of Isaac, a Software & App Developer in Kenya. His only services: ${SERVICES.join(', ')}. Recommend 1-3 of those services that fit the client's needs, each with a one-sentence reason. Then draft a short, friendly inquiry (under 150 words) written by the client to Isaac, describing their needs. Never invent prices, timelines, past results or credentials for Isaac. Leave [Your name] as a placeholder.`,
        messages: [{ role: 'user', content: data.needs }],
        output: Output.object({ schema: resultSchema }),
        maxRetries: 0,
        providerOptions: { openai: { store: false, forceReasoning: true, reasoningEffort: 'low', include: ['reasoning.encrypted_content'] } },
      });
      return await result.output;
    } catch (err) {
      const status = (err as { statusCode?: number })?.statusCode;
      console.error('advisor error', status, err);
      if (status === 429) return { error: 'The assistant is busy. Please try again in a minute.' };
      if (status === 402) return { error: 'The assistant is temporarily unavailable (AI credits exhausted).' };
      return { error: 'The assistant could not answer right now. Please try again later.' };
    }
  });
