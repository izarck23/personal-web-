import { createFileRoute } from '@tanstack/react-router';
import { ArticleCard } from '@/components/portfolio/article-card';
import { SiteHeader, SiteFooter } from '@/components/portfolio/site-chrome';
import { articles } from '@/content/articles';
import { SITE_URL } from '@/components/portfolio/social';
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { useReadingList } from '@/components/portfolio/reading-list';

export const Route = createFileRoute('/blog/')({
  staticData: { sitemap: true },
  head: () => ({
    meta: [
      { title: 'App & Landing Page Development Blog — Isaac, Kenya' },
      { name: 'description', content: 'Guides by Isaac, a Kenyan software developer, and tutorials on app development, AI-assisted coding, responsive websites and website SEO.' },
      { property: 'og:title', content: 'App & Landing Page Development Blog — Isaac, Kenya' },
      { property: 'og:description', content: 'Practical guides and tutorials on app development, coding and website SEO.' },
      { property: 'og:type', content: 'website' },
      { property: 'og:url', content: `${SITE_URL}/blog` },
      { name: 'twitter:card', content: 'summary_large_image' },
    ],
    links: [{ rel: 'canonical', href: `${SITE_URL}/blog` }],
  }),
  component: Blog,
});

function Blog() {
  const [savedOnly, setSavedOnly] = useState(false);
  const { saved, ready, error } = useReadingList();
  const visible = savedOnly ? articles.filter((article) => saved.includes(article.slug)) : articles;
  return <div className="portfolio-site"><SiteHeader activeSection="blog" /><main className="section container"><div className="eyebrow">Development journal</div><h1 className="section-heading">CoderTech <span className="orange">Blog</span></h1>
    <div className="reading-list-controls" role="group" aria-label="Article view"><Button variant={savedOnly ? 'portfolioOutline' : 'portfolio'} aria-pressed={!savedOnly} onClick={() => setSavedOnly(false)}>All articles</Button><Button variant={savedOnly ? 'portfolio' : 'portfolioOutline'} aria-pressed={savedOnly} onClick={() => setSavedOnly(true)}>Reading list{ready ? ` (${saved.length})` : ''}</Button></div>
    {error && <p role="status">{error}</p>}
    {savedOnly && !ready ? <p role="status">Loading reading list…</p> : visible.length ? <div className="article-grid">{visible.map((article) => <ArticleCard key={article.slug} article={article} />)}</div> : <p role="status" className="reading-list-empty">No saved articles yet.</p>}
  </main><SiteFooter /></div>;
}