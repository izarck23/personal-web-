// Real project facts stay as supplied by Isaac; images are AI-generated concepts until real screenshots replace them.
// To replace an image: drop the real file in src/assets/ and change the import below.
import genzii from '@/assets/genzii-screens.webp';
import startup from '@/assets/generated/concept-startup-pages.jpg';
import landing from '@/assets/generated/concept-landing-pages.jpg';
import salonAsset from '@/assets/luxe-salon-desktop.png.asset.json';
const salon = salonAsset.url;

export type ProjectLink = { label: string; href: string };
export type Project = { slug: string; title: string; category: string; description: string; body: string[]; image: string; imageAlt: string; seoTitle: string; seoDescription: string; heading: string; relatedCategory: string; links?: ProjectLink[] };
export const luxeSalonLinks: ProjectLink[] = [
  { label: 'Preview the live website', href: 'https://izarck23.github.io/luxe-salon-website/' },
  { label: 'Preview the template', href: 'https://izarck23.github.io/luxe-salon-website/' },
  { label: 'Download the code (ZIP)', href: 'https://github.com/izarck23/luxe-salon-website/archive/refs/heads/main.zip' },
  { label: 'View the code on GitHub', href: 'https://github.com/izarck23/luxe-salon-website' },
];

const tpl = (slug: string): ProjectLink[] => [
  { label: 'Preview the template', href: `/templates/${slug}/index.html` },
  { label: 'Download the editable code (ZIP)', href: `/downloads/${slug}-template.zip` },
];
export const startupLinks = tpl('startup');
export const landingLinks = tpl('landing-page');
export const projects: Project[] = [
  { slug: 'genzii', title: 'Genzii', category: 'App project', heading: 'Genzii app development', description: 'Status and contributions: [details to add].', body: ['App project confirmed by Isaac.', 'Status: [to confirm]. My contributions: [to add]. Technical stack: [to add].', 'Actual screenshots and project link: [to add].'], image: genzii, imageAlt: 'Genzii app UI screens: onboarding, AI assistant, originality checker and vault', seoTitle: 'Genzii App Development — Isaac, Software Developer Kenya', seoDescription: 'Genzii is an app project by Isaac, a software and app developer in Kenya. Project status and contributions are being documented.', relatedCategory: 'Genzii Journey' },
  { slug: 'startup-pages', title: 'Startup Pages', category: 'Website projects', heading: 'Startup website development', description: 'Editable HTML & CSS startup website template — preview or download.', body: ['Startup page projects confirmed by Isaac.', 'Individual project names, status, my contributions and technical stack: [to add].', 'Actual screenshots and project links: [to add].'], image: startup, imageAlt: 'Concept illustration of a startup website homepage — not actual client work', seoTitle: 'Startup Website Development — Isaac, Kenya', seoDescription: 'Startup website pages built by Isaac, a web developer in Kenya. Individual project details are being added.', relatedCategory: 'Landing Pages', links: startupLinks },
  { slug: 'landing-pages', title: 'Landing Pages', category: 'Website projects', heading: 'Startup landing page development', description: 'Editable HTML & CSS product landing page template — preview or download.', body: ['Landing page projects confirmed by Isaac.', 'Individual project names, status, my contributions and technical stack: [to add].', 'Actual screenshots and project links: [to add].'], image: landing, imageAlt: 'Concept illustration of a landing page on a tablet and phone — not actual client work', seoTitle: 'Startup Landing Page Development — Isaac, Kenya', seoDescription: 'Landing page development by Isaac, a software developer in Kenya, for startups and small businesses.', relatedCategory: 'Landing Pages', links: landingLinks },
  { slug: 'luxe-salon', title: 'Luxe Salon', category: 'Website project', heading: 'Salon website development', description: 'Salon, barbershop & spa website for Westlands, Nairobi.', body: ['A website for Luxe Salon & Barber, a hair salon, barbershop and spa in Westlands, Nairobi.', 'Features shown: services and prices in KSh, appointment booking, booking tracking, about & team, contact, sign in and a light/dark mode switch.', 'My contributions, technical stack, project timeline and live link: [details to add].'], image: salon, imageAlt: 'Luxe Salon & Barber website homepage: dark hero with booking buttons, prices from KSh 300 and opening hours', seoTitle: 'Luxe Salon — Salon Website Development by Isaac', seoDescription: 'Luxe Salon is a salon website development project by Isaac, a web developer in Kenya. Details are being documented.', relatedCategory: 'Website Development', links: luxeSalonLinks },
];
export const getProject = (slug: string) => projects.find((project) => project.slug === slug);
