export type Template = { slug: string; title: string; category: string; description: string; includes: string[]; price: number | null; pages: { label: string; file: string }[] };
export const templates: Template[] = [
  { slug: 'landing-page', title: 'Product Landing Page', category: 'Marketing', description: 'A focused product page with features, pricing sections and frequently asked questions.', includes: ['Product introduction and calls to action', 'Responsive feature and pricing layouts', 'Native expandable FAQs'], price: null, pages: [{ label: 'Landing page', file: 'index.html' }] },
  { slug: 'startup', title: 'Startup Website', category: 'Business', description: 'A startup website with a product overview, team, milestones and a waitlist layout.', includes: ['Product overview and dashboard UI', 'Team and milestone sections', 'Waitlist form layout — delivery not connected'], price: null, pages: [{ label: 'Startup page', file: 'index.html' }] },
  { slug: 'authentication', title: 'Authentication Screens', category: 'Account UI', description: 'Professional sign-in, sign-up and password-reset screens ready to adapt to your website.', includes: ['Sign in, create account and reset password', 'Accessible labels and native field validation', 'UI only — no accounts, sessions or email delivery'], price: null, pages: [{ label: 'Sign in', file: 'index.html' }, { label: 'Create account', file: 'signup.html' }, { label: 'Reset password', file: 'reset.html' }] },
];
export const getTemplate = (slug: string) => templates.find((item) => item.slug === slug);
export const templateURL = (slug: string, file = 'index.html') => `/templates/${slug}/${file}`;
export const templateZip = (slug: string) => `/downloads/${slug}-template.zip`;
export function addCartItem(items: string[], slug: string): string[] { return getTemplate(slug) ? [...new Set([...items, slug])] : items; }
export function cartTotal(items: string[]): number | null { const selected = templates.filter((item) => items.includes(item.slug)); return selected.some((item) => item.price === null) ? null : selected.reduce((sum, item) => sum + (item.price ?? 0), 0); }
